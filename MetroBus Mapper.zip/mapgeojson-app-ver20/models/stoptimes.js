class Time {
    constructor(id, trip_id, arrival_time, departure_time, stop_id, route_id) {
            this._id = id;
            this.trip_id = trip_id;
            this.arrival_time = arrival_time;
            this.departure_time = departure_time;
            this.stop_id = stop_id;
            this.route_id = route_id;

        }
        //inserts the bus stop data.
    savestoptimes(collection) {
        let loc = this;
        return new Promise((resolve, reject) => {
            collection.insertOne(loc, (err, obj) => {
                if (err) return reject(err);
                console.log('Stop time data was inserted in the database');
                resolve({ msg: 'Stop time data point data was successfully saved in the database' })
            });
        });

    }

    static getstopidById(collection, id) {
        var id_get = id;
        return new Promise(async function(resolve, reject) {
            collection.find({ "stop_id": (id_get) }).toArray(function(err, obj) {
                if (obj == null) {
                    resolve({ msg: 'Stop id is not in the database' });
                }
                if (err) return reject(err);
                console.log("server-side: Bus Stop Data was retrieve");
                resolve({ times: obj }, { msg: 'client-side: Bus Stop Data was retrieved' });
            });
        });

    };


}

module.exports = Time;