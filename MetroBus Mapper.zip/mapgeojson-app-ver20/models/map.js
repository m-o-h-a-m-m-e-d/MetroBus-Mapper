class Location {
    constructor(id, properties, geometry) {
            this._id = id;
            this.properties = properties;
            this.geometry = geometry;

        }
        //inserts the bus stop data.
    savebusstops(collection) {
            let loc = this;
            return new Promise((resolve, reject) => {
                collection.insertOne(loc, (err, obj) => {
                    if (err) return reject(err);
                    console.log('A Bus Stop point was inserted in the database');
                    resolve({ msg: 'The Bus Stop point data was successfully saved in the database' })
                });
            });

        }
        //inserts the route data to a different collection than the bus stop data .
    savebusroutes(collection) {
            let loc = this;
            return new Promise((resolve, reject) => {
                collection.insertOne(loc, (err, obj) => {
                    if (err) return reject(err);
                    console.log('A Route was inserted in the database with id');
                    resolve({ msg: 'The Route data was successfully saved in the database' })
                });
            });

        }
        //gets stop data with the same id as inputted
    static getstopById(collection, id) {
        var id_get = id;
        return new Promise(async function(resolve, reject) {
            collection.find({ "properties.routes.route_id": (id_get) }).toArray(function(err, obj) {
                if (obj == null) {
                    resolve({ msg: 'Busstop id is not in the database' });
                }
                if (err) return reject(err);

                console.log("server-side: Bus Stop Data was retrieve");
                resolve({ maps: obj }, { msg: 'client-side: Bus Stop Data was retrieved' });
            });
        });

    };
    //gets route data with the same id as inputted
    static async getrouteById(collection, id) {
        var id_get = id;
        return new Promise(async function(resolve, reject) {
            collection.find({ "properties.route_id": (id_get) }).toArray(function(err, obj) {
                if (obj == null) {
                    resolve({ msg: 'Route id is not in the database' });
                }
                if (err) return reject(err);
                console.log("server-side: Route Data was retrieve");
                resolve({ maps: obj }, { msg: 'client-side: Route Data was retrieved' });
            });
        });
    };

}

module.exports = Location;