var request = require('request');
var myurl = 'http://localhost:3000';



request.post({
    headers: { 'content-type': 'application/json' },
    url: myurl + '/mapsstoptime',
}, function(error, response, body) {
    if (error) console.log(error);
    console.log(body);
});