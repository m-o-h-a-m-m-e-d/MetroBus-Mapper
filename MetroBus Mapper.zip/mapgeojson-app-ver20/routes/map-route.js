const express = require('express')
const router = express.Router()
const map_controller = require("../controller/map-controller")

router.post("/", map_controller.createbustops)
router.get("/:id", map_controller.getbusstop)

module.exports = router