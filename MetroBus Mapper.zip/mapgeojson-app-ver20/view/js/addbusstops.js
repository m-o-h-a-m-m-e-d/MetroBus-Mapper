$(document).ready(function() {
    // The following function runs when the addbustop button is pressed and it is suppose to send a request to add all the bus stop data into mongodb database
    $("#btn-addbusstops").click(function(event) {
        event.preventDefault();
        $.ajax({
            url: '/maps',
            type: 'POST',
            contentType: 'application/json',
            success: function(response) {
                console.log(JSON.stringify(response));
                $("#add-out").text(response);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});