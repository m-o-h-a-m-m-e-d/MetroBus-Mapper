$(document).ready(function() {
    // The following function runs when the addroutes button is pressed and it is suppose to send a request to add all the route data into mongodb database
    $("#btn-addroutes").click(function(event) {
        event.preventDefault();
        $.ajax({
            url: '/mapsroutes',
            type: 'POST',
            contentType: 'application/json',
            success: function(response) {
                console.log(JSON.stringify(response));
                $("#add-out").text(response);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText
                alert('Error - ' + errorMessage);
            }
        });
    });


});