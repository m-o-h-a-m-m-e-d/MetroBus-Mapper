$(document).ready(function() {
    // The following function runs when the showfares button is pressed it hides any schedule elements and displays the fares table in its place
    $("#btn-showfares").click(function(event) {
        event.preventDefault();
        $(".listtimes").hide();
        $(".showfares").show();

    });
    // The following function runs when the Metrobus Twitter button is pressed and it opens a new tab to go to the Metrobus twitter
    $("#btn-metrotwitter").click(function(event) {
        event.preventDefault();
        window.open('https://twitter.com/metrobustransit?lang=en');


    });


});