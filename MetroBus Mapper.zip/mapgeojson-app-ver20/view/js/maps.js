var map = L.map('map').setView([47.560539, -52.712830], 13);
var baseMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', { foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' });

var baseMaps = {
    "OpenStreetMap": baseMap
};

baseMap.addTo(map);
//The code above helps setup the map. It sets the map the view St.John where our project is based of.

// The function bellow is for when the clear map button is pressed the map is reset and all the layers are remove so it goes back to the default setted up map
$("#btn-clear").click(function(event) {
    map.eachLayer(function(layer) {
        map.removeLayer(layer);
    });
    baseMap.addTo(map);
});



//This function was implemented to reduce duplication. The purpose is to create a schedule for each busstop when the button in the popup is pressed.It also calculates the next bus arrival time based of the current time and gives and estimate for that too.
function createschedule(res, id, n) {
    var response = res;
    var i = id;
    var numberroute = n;
    L.geoJson(response.maps[i].geometry, {
        onEachFeature: function(feature, layer) {
            let btnDiv = document.createElement('div')
                //message for the popup to display the stop name and stop id also a button called schedule.
            let msg = document.createElement('h3');
            msg.innerHTML = response.maps[i].properties.stop_name + " - Stop ID - " + response.maps[i].properties.stop_id;


            let btnschedule = document.createElement('button');
            btnschedule.innerHTML = "Schedule";
            btnschedule.className = 'btnpopup';

            var id_input = response.maps[i].properties.stop_id;
            // when the button is clicked the following function is ran and gets the schedule for a pericular stop.
            btnschedule.onclick = async() => {
                $(".showfares").hide();
                $(".listtimes").show();
                $("#list-times").empty();
                let tbl = '<table id="table-list"><tr><th>Route Id</th><th>Arrival Time</th><th>Departure Time</th></tr></table>';
                $("#list-times").append(tbl);
                var arrivaltimesarr = [];
                var resulttimesarr = [];
                $.ajax({
                    url: '/mapsstoptime/' + id_input,
                    type: 'GET',
                    contentType: 'application/json',
                    success: function(response) {
                        //creates a table for the data recived
                        for (let i = 0; i < response.times.length; i++) {
                            let obj = response.times[i];
                            let tbl_line = '';
                            /**  To add an effect in the table, we can apply
                                 even and odd classes. */
                            if (obj.route_id == numberroute.toString()) {
                                if (i % 2 == 0) {
                                    tbl_line = '<tr class="even-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                } else {
                                    tbl_line = '<tr class="odd-row"><td>' + obj.route_id + '</td><td>' + obj.arrival_time + '</td><td>' + obj.departure_time + '</td><tr/>';
                                }
                                $("#table-list").append(tbl_line)
                            }
                            arrivaltimesarr.push(obj.arrival_time);
                            //code to help calculate the next bus arrival
                            var today = new Date();
                            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();

                            var a = time.toString();
                            var b = arrivaltimesarr[i].toString();

                            var difference = (toSeconds(a) - toSeconds(b));

                            resulttimesarr.push(difference);

                        }

                        var themsg = ("The next bus arrives at this stop in: ");
                        var a = nextbus(resulttimesarr);
                        $("#next-bus").text(themsg + a.toString());



                    },
                    error: function(xhr, status, error) {
                        var errorMessage = xhr.status + ': ' + xhr.statusText
                        alert('Error - ' + errorMessage);
                    }
                });

            }

            btnDiv.append(msg)
            btnDiv.append(btnschedule)
                //adds all the following to the popup
            layer.bindPopup(btnDiv)
        },
    }).addTo(map);

}
//The following code is a litte messy and could have been improve. But it is like this because the function of it is add the route ad stops and pop ups
//Each route button has its on function and adds data based on what route button is added.

$("#btn-route1").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/1',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 1);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});



$("#btn-route2").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/2',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 2);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route3").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/3',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 3);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route5").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/5',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 5);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route6").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/6',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 6);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route9").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/9',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 9);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route10").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/10',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 10);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route11").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/11',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 11);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route12").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/12',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 12);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route14").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/14',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 14);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route15").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/15',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 15);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route16").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/16',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 16);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route18").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/18',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 18);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route19").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/19',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 19);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route20").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/20',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 20);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route21").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/21',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 21);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});
$("#btn-route22").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/22',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 22);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

$("#btn-route23").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/23',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 23);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});


$("#btn-route30").click(function(event) {
    event.preventDefault();
    $.ajax({
        url: '/mapsroutes/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                var myStyle = {
                    "color": "#ff7800",
                    "weight": 5,
                    "opacity": 0.65
                };
                L.geoJson(response.maps[i].geometry, {
                    onEachFeature: function(feature, layer) {
                        layer.bindPopup('<h3>' + response.maps[i].properties.route_long_name + '</h3>');
                    },
                    style: myStyle
                }).addTo(map);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });


    $.ajax({
        url: '/maps/30',
        type: 'GET',
        contentType: 'application/json',
        success: function(response) {
            for (var i = 0; i < response.maps.length; i++) {
                createschedule(response, i, 30);
            }

        },
        error: function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Error - ' + errorMessage);
        }
    });
});

//the following two functions help calculate the next bus arrival

function toSeconds(time_str) {
    // Extract hours, minutes and seconds
    var parts = time_str.split(':');
    // compute  and return total seconds
    return parts[0] * 3600 + // an hour has 3600 seconds
        parts[1] * 60 + // a minute has 60 seconds
        +parts[2]; // seconds
}

function nextbus(array) {
    resulttimesarr = array;
    var mintime = -100000000000000000;
    for (let i = 0; i < resulttimesarr.length; i++) {
        if (resulttimesarr[i] < 0) {
            if (resulttimesarr[i] > mintime) {
                mintime = resulttimesarr[i];
            }
        }
    }

    var mintime = Math.abs(mintime);
    var result = [
        // an hour has 3600 seconds so we have to compute how often 3600 fits
        // into the total number of seconds
        Math.floor(mintime / 3600), // HOURS
        // similar for minutes, but we have to "remove" the hours first;
        // this is easy with the modulus operator
        Math.floor((mintime % 3600) / 60), // MINUTES
        // the remainder is the number of seconds
        mintime % 60 // SECONDS
    ];

    // formatting (0 padding and concatenation)
    result = result.map(function(v) {
        return v < 10 ? '0' + v : v;
    }).join(':');

    return result

}